
Name: WKRTE
Description: jQuery Rich text editor based on LWRTE (http://code.google.com/p/lwrte/)
Project URI: http://code.google.com/p/wkrte/
Version: 0.1
Demo URI: http://web-kreation.com/demos/wkrte_jquery-rich-text-editor/

========
DOWNLOAD
========

Download: http://code.google.com/p/wkrte/downloads/list

======
LICENSE
======

Released under MIT License: http://www.opensource.org/licenses/mit-license.php

==========
INSTALLATION
==========

- Unzip the file.
- Upload the files and folders in the root directory of your Web site on your server.
- Modify code as you wish.

=====
USAGE
=====

http://code.google.com/p/wkrte/wiki/Usage

=====================
CONTRIBUTE TO THIS PROJECT
=====================

Developers, you can join and contribute to this opensource project here: http://code.google.com/p/wkrte/
Developer guide can be found here: http://code.google.com/p/wkrte/wiki/Toolbar

Google Groups: http://groups.google.com/group/wkrte

=======
CONTACT
=======

Do not hesitate to contact me at jeremie@web-kreation.com if you have any question.



